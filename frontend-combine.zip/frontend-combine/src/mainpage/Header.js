import React from 'react';
import '../css/Header.css'

const Header = () => {
    return (
        <header>
            <nav>영남대학교 컴퓨터공학과 사물함</nav>
        </header>
    );
}

export default Header;